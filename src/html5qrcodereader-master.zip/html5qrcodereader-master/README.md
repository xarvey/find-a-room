HTML5 QR-code reader - no flash, only html and javascript

A very basic QR-code reader based on:

- jQuery: http://jquery.com/
- Photobooth.js: http://wolframhempel.github.io/photobooth-js/
- QR-code library: https://github.com/LazarSoft/jsqrcode
- Say cheese: http://leemachin.github.io/say-cheese/


First example (index.html) uses photobooth.js to read an image 
from the webcam, but the width and height of the video is not correct.
I will correct it in future.

Second example (index_saycheese.html) uses saycheese.js to read 
from webcam and the video is correct.


Also tested with mobile browsers (Firefox and Chrome).


Usage:
Only clone or download this script and test it on your local 
webserver.
Enjoy!


To-do:
- setting correct width and height of webcam stream for photobooth.js